
  # Event Dashboard

  This is a code bundle for Event Dashboard. The original project is available at https://www.figma.com/design/W8nLdzmzNGRgnvxAQ6kubi/Event-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  